/*
    pbTemp1.h - Library for measure Temperature.
    Created by Dushyantha N. Wijesinghe (Co - Founder of PurchBest.com), November 2018
    Released into the public domain
    for https://www.purchbest.com
    compatible devices - pbT1 temperature sensor by PurchBest.com
*/

#ifndef pbTemp1_h
#define pbTemp1_h

#include <math.h>

class pbTemp1
{
    public:
        pbTemp1();
        float tempRk(float resistance);
        float tempAk(int analogValue);
        float tempAc(int analogValue);
        float tempAf(int analogValue);
    private:
};
#endif // pbTemp_h
