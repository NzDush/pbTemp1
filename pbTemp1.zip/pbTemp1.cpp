/*
    pbTemp1.cpp - Library for measure Temperature.
    Created by Dushyantha N. Wijesinghe (Co - Founder of PurchBest.com), November 2018
    Released into the public domain
    for https://www.purchbest.com
    compatible devices - pbT1 temperature sensor by PurchBest.com
*/

#include "Arduino.h"
#include "pbTemp1.h"

pbTemp1::pbTemp1()
{
}
/*
float pbTemp::tempAc(int analogValue){
  return ((1/((log(((1024*10000UL/analogValue)-10000)/10000)/3950)+(1/298.15)))-273.15);
}
*/
float pbTemp1::tempRk(float resistance){
  return (1/((log(resistance/10000)/3950)+(1/298.15)));
}

float pbTemp1::tempAk(int analogValue){
  return tempRk((1024*10000UL/analogValue)-10000);
}

float pbTemp1::tempAc(int analogValue){
  return (tempAk(analogValue)-273.15);
}

float pbTemp1::tempAf(int analogValue){
  return ((tempAc(analogValue)*1.8)+32);
}

